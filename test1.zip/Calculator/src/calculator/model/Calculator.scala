package calculator.model

import calculator.model.States.{CalculatorBase, ClearCalculator}

class Calculator() {

  var Sides: Array[Double] = Array(0,0)
  var Decimal: String = ""
  var DisplayString: String = Sides(0).toString

  // Map of operation functions
  val Operations: Map[String, () => Double] = Map(
    "+" -> { () => this.Sides(0) + this.Sides(1) },
    "-" -> { () => this.Sides(0) - this.Sides(1) },
    "*" -> { () => this.Sides(0) * this.Sides(1) },
    "/" -> { () => this.Sides(0) / this.Sides(1) }
  )

  var CurrentSide: Int = 0 // 0 for Left, 1 for Right
  var CurrentOperator: String = "+" // String to select from Operations map
  var PreviousOperator: String = "+"

  var State: CalculatorBase = new ClearCalculator(this)

  // Accessed by View. You should edit this method as you build functionality
  def displayNumber(): Double = {
    //println("---- NEW STEP ----")
    //println(Sides(0))
    //println(CurrentOperator)
    //println(Sides(1))
    this.State.displayNumber()
  }

  def clearPressed(): Unit = {
    this.State.clearPressed()
  }

  def numberPressed(number: Int): Unit = {
    this.State.numberPressed(number)
  }

  def dividePressed(): Unit = {
    this.State.dividePressed()
  }

  def multiplyPressed(): Unit = {
    this.State.multiplyPressed()
  }

  def subtractPressed(): Unit = {
    this.State.subtractPressed()
  }

  def addPressed(): Unit = {
    this.State.addPressed()
  }

  def equalsPressed(): Unit = {
    this.State.equalsPressed()
  }

  def decimalPressed(): Unit = {
    this.State.decimalPressed()
  }

}
