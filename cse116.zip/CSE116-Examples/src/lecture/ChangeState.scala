package lecture

object ChangeState {

  /**
    * Sets the the internal state of _number in the input to zero
    * @param input The input object of type NumberProtector
    */
  def setToZero(input: NumberProtector): Unit = {

  }

}
