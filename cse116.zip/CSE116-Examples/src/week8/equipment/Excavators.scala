package week8.equipment

class Excavators extends Equipment{

  this.name = "Excavator"


}
