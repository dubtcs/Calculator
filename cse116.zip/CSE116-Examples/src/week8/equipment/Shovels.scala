package week8.equipment

class Shovels extends Equipment {

  this.name = "Shovel"


}
