package week8.equipment

class GoldMines extends Equipment{

  this.name = "Gold Mine"

}
