package week3.memory

class ClassWithState(var state: Int) {

}
