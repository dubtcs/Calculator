package week13.mmo

case object Update
