package tests

import org.scalatest.FunSuite
import week8.trees._

class TestExpressionTree extends FunSuite {

     test("E"){

          var Root: BinaryTreeNode[String] = new BinaryTreeNode[String]("+",null,null)

          Root.left = new BinaryTreeNode[String]("-",null,null)
          Root.left.left = new BinaryTreeNode[String]("6",null,null)
          Root.left.right = new BinaryTreeNode[String]("1",null,null)

          Root.right = new BinaryTreeNode[String]("5",null,null)

          assert(ExpressionTree.evaluateTree(Root) == 10)

          Root = new BinaryTreeNode[String]("0",null,null)

          assert(ExpressionTree.evaluateTree(Root) == 0)

     }

}
