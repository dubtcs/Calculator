package tests

import org.scalatest.FunSuite
import week8.linkedlist.LinkedListNode

class TestReduce extends FunSuite {

     test("E"){

          var myList: LinkedListNode[Int] = new LinkedListNode[Int](4,null)
          myList = new LinkedListNode[Int](6,myList)
          myList = new LinkedListNode[Int](2,myList)

          val myFunc: (Int,Int) => Int = (a: Int, b: Int) => a + b

          assert(myList.reduce(myFunc) == 12)

          myList = new LinkedListNode[Int](0,null)
          myList = new LinkedListNode[Int](-5,myList)
          myList = new LinkedListNode[Int](3,myList)

          assert(myList.reduce(myFunc) == -2)

          myList = new LinkedListNode[Int](0,null)

          assert(myList.reduce(myFunc) == 0)

          myList = new LinkedListNode[Int](1,null)
          for (i <- 1 to 30){
               myList = new LinkedListNode[Int](1,myList)
          }


          assert(myList.reduce(myFunc) == 31)


     }

}
