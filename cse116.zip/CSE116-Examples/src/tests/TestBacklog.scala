package tests

import org.scalatest.FunSuite
import datastructures.Backlog

class BRUH(){

     var used: Boolean = false

     def use(): Unit = {
          used = true
     }

}

class TestBacklog extends FunSuite {

     test("E)"){

          val dhu9awdah98h8wa: (BRUH) => Unit = (a: BRUH) => a.use()
          val Log: Backlog[BRUH] = new Backlog[BRUH](dhu9awdah98h8wa)

          val b1: BRUH = new BRUH
          val b2: BRUH = new BRUH

          Log.completeTask()
          Log.addTask(b1)
          Log.addTask(b2)
          assert(!b1.used)
          assert(!b2.used)
          Log.completeTask()
          assert(b1.used)
          assert(!b2.used)
          Log.completeTask()
          assert(b1.used)
          assert(b2.used)

     }

}
