package week2.objects

class Point2D(var x: Double, var y: Double) {

}
