package project.backend.battlesystem

import akka.actor.{Actor, ActorRef}


class BattleSystem(server: ActorRef) extends Actor {


  override def receive: Receive = {
    case _ =>

  }

}
