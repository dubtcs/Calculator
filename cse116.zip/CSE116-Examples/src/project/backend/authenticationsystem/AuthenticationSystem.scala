package project.backend.authenticationsystem

import akka.actor.Actor


class AuthenticationSystem  extends Actor{


  override def receive: Receive = {
    case _ =>

  }

}
