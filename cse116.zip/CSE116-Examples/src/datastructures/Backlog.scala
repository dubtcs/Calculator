package datastructures

import week8.linkedlist._

class Backlog[A](TaskFunction: (A) => Unit) {

     var Queue: Queue[A] = new Queue[A]

     def addTask(Task: A): Unit = {
          Queue.enqueue(Task)
     }

     def completeTask(): Unit = {
          if (!Queue.empty()) {
               TaskFunction(Queue.dequeue())
          }
     }

}
