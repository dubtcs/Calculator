package week4.json

class Location(val latitude: Double, val longitude: Double) {

}
